import sys
import xbmcgui
import xbmcplugin
import requests

import json

_url = sys.argv[0]  # url is not need the way I'm doing it
# required for pinpointing plugin, treat as a pointer to the plugin instance
_handle = int(sys.argv[1])


class Item():
    def __init__(self):
        pass


mediaLinks = [
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep1/914203',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep2/914207',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep3/915774',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep4/915773',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep5/916004',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep6/917561',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep7/918941',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep8/920160',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep9/920444',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep10/922768',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep11/920830',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep12/922732',
    'https://www.mewatch.sg/en/series/titoudao-inspired-by-the-true-story-of-a-wayang-star/ep13/922733'
]

def main():
    createNewDirectory()
    populateDirectory(mediaLinks)
    endDirectoryCreation()


def createNewDirectory():
    xbmcplugin.setContent(_handle, 'videos')


def endDirectoryCreation():
    xbmcplugin.endOfDirectory(_handle)


def addItemToDirectory(item):
    xbmcItem = _buildVideoItem(item)
    print('item.videoURL', item.videoURL)
    xbmcplugin.addDirectoryItem(_handle, item.videoURL, xbmcItem, False)


def _buildVideoItem(item):
    listItem = xbmcgui.ListItem(label=item.epName)
    listItem.setInfo('video', {'title': item.epName,
                               'genre': item.epName,
                               'mediatype': 'video'})

    listItem.setArt({
        'thumb': item.imageURL
    })

    listItem.setProperty('IsPlayable', 'true')

    listItem.setSubtitles(item.subtitles)
    
    return listItem


def fetchAPIData(referer):

    mediaId = referer.split('/')[-1]

    headers = {
        'Connection': 'keep-alive',
        'Accept': '*/*',
        'Origin': 'https://www.mewatch.sg',
        'Sec-Fetch-Dest': 'empty',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Sec-Fetch-Site': 'cross-site',
        'Sec-Fetch-Mode': 'cors',
        'Referer': '{}'.format(referer),
        'Accept-Language': 'en-US,en;q=0.9',
    }

    params = (
        ('m', 'GetMediaInfo'),
    )

    data = '{"initObj":{"Platform":"Web","SiteGuid":"","DomainID":"0","UDID":"","ApiUser":"tvpapi_147","ApiPass":"11111","Locale":{"LocaleLanguage":"","LocaleCountry":"","LocaleDevice":"","LocaleUserState":"Unknown"}},"MediaID":"' + mediaId + '"}'

    response = requests.post(
        'https://tvpapi-as.ott.kaltura.com/v3_9/gateways/jsonpostgw.aspx', headers=headers, params=params, data=data)



    episodeResponse = response.json()
    
    
    showName = episodeResponse['MediaName']
    videoURL = episodeResponse['Files'][-1]['URL']

    shortTitle = ''

    for meta in episodeResponse['Metas']:
            if meta['Key'] == "Short title":
                shortTitle = meta['Value']

    imageURL = episodeResponse['Pictures'][-1]['URL']


    epNo = ""

    for meta in episodeResponse['Metas']:
            if meta['Key'] == "Episode number":
                epNo = meta['Value']

    epName = ""
    for meta in episodeResponse['Metas']:
            if meta['Key'] == "Episode name":
                epName = meta['Value']
    
    subtitles = getSubtitles(referer, mediaId)

    item = Item()
    item.showName = showName
    item.videoURL = videoURL
    item.shortTitle = shortTitle
    item.imageURL = imageURL
    item.epNo = epNo
    item.epName = epName
    item.subtitles = subtitles

    return item


def getSubtitles(referer, mediaId):
    headers = {
        'authority': 'sub.toggle.sg',
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'sec-fetch-dest': 'empty',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
        'origin': 'https://www.mewatch.sg',
        'sec-fetch-site': 'cross-site',
        'sec-fetch-mode': 'cors',
        'referer': '{}'.format(referer),
        'accept-language': 'en-US,en;q=0.9',
    }

    params = (
        ('mediaId', mediaId),
    )

    response = requests.get(
        'https://sub.toggle.sg/toggle_api/v1.0/apiService/getSubtitleFilesForMedia', headers=headers, params=params)

    subtitlesResponse = response.json()

    subtitles = _getAllSubtitles(subtitlesResponse)

    return subtitles

def _getAllSubtitles(resp):
    subtitles = []

    for subtitle in resp['subtitleFiles']:
        subtitles.append(subtitle['subtitleFileUrl'])

    return subtitles


def populateDirectory(mediaLinks):
    for mediaLink in mediaLinks:
        item = fetchAPIData(mediaLink)
        addItemToDirectory(item)

if __name__ == '__main__':
    main()
